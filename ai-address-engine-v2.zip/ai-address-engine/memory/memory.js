// In-memory store (resets on server restart)
// For persistence, replace with a database or file-based store

const cache = new Map();         // input → output
const corrections = new Map();   // manually corrected input → output

function getCached(input) {
  const entry = cache.get(input);
  if (!entry) return null;
  return entry;
}

function save(input, output) {
  cache.set(input, { input, output, savedAt: Date.now() });
}

function getCorrection(input) {
  return corrections.get(input) || null;
}

function addCorrection(input, output) {
  corrections.set(input, output);
}

function getAllCorrections() {
  return Object.fromEntries(corrections);
}

function getCacheSize() {
  return cache.size;
}

module.exports = {
  getCached,
  save,
  getCorrection,
  addCorrection,
  getAllCorrections,
  getCacheSize
};
