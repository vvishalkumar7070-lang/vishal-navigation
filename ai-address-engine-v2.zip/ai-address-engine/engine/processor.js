const { extract }       = require("../services/ai");
const { search, fetchNearby } = require("../services/search");
const { clean, normalize }    = require("../utils/cleaner");
const { score }         = require("./scorer");
const { getCached, save, getCorrection } = require("../memory/memory");

/**
 * Core pipeline: clean → extract → geocode → score → return best result.
 * @param {string} text - Raw user query
 * @returns {Object} Result with best match, suggestions, nearby, confidence
 */
async function process(text) {
  if (!text || !text.trim()) return { error: "Empty query" };

  // Check manual corrections first
  const correction = getCorrection(text);
  if (correction) return { ...correction, source: "correction" };

  // Check in-memory cache
  const cached = getCached(text);
  if (cached) return { ...cached.output, source: "cache" };

  // Clean and normalize input
  const cleaned = normalize(clean(text));

  // AI extraction of structured fields
  const data = await extract(cleaned);

  // Build multiple search queries for better coverage
  const queries = [
    cleaned,
    [data.landmark, data.city].filter(Boolean).join(" "),
    [data.sector, data.city].filter(Boolean).join(" "),
    [data.landmark, data.state].filter(Boolean).join(" "),
  ].filter(q => q.trim().length > 0);

  // Deduplicate queries
  const uniqueQueries = [...new Set(queries)];

  // Fetch results from all queries
  let results = [];
  for (const q of uniqueQueries) {
    const r = await search(q);
    results = results.concat(r);
  }

  if (!results.length) return { error: "Location not found. Try a more specific query." };

  // Score and sort results
  const scored = results
    .map(p => ({ ...p, score: score(p, data) }))
    .sort((a, b) => b.score - a.score);

  const best = scored[0];

  // Fetch nearby landmarks for the best result
  const nearby = await fetchNearby(
    parseFloat(best.lat),
    parseFloat(best.lon)
  );

  const output = {
    best: {
      display_name: best.display_name,
      lat: best.lat,
      lon: best.lon,
      address: best.address || {}
    },
    nearby,
    suggestions: scored.slice(1, 4).map(p => ({
      display_name: p.display_name,
      lat: p.lat,
      lon: p.lon
    })),
    confidence: best.score,
    extracted: data,
    source: "live"
  };

  save(text, output);
  return output;
}

module.exports = { process };
