/**
 * Scores a geocoding result based on how well it matches extracted fields.
 * Higher score = better match.
 * @param {Object} place - Nominatim result object
 * @param {Object} data  - Extracted fields { sector, landmark, city, state }
 * @returns {number}
 */
function score(place, data) {
  let s = 0;
  const name = (place.display_name || "").toLowerCase();

  if (data.sector   && name.includes(data.sector.toLowerCase()))   s += 50;
  if (data.landmark && name.includes(data.landmark.toLowerCase())) s += 30;
  if (data.city     && name.includes(data.city.toLowerCase()))     s += 20;
  if (data.state    && name.includes(data.state.toLowerCase()))    s += 10;

  // Bonus: India-specific results rank higher
  if (name.includes("india")) s += 5;

  return s;
}

module.exports = { score };
