const axios = require("axios");

const GROQ_KEY = process.env.GROQ_API_KEY || "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";

/**
 * Uses Groq LLaMA to extract structured location data from free-text input.
 * @param {string} text - Raw user input
 * @returns {Object} { sector, landmark, city, state }
 */
async function extract(text) {
  if (!GROQ_KEY) {
    console.warn("⚠️  GROQ_API_KEY not set — skipping AI extraction");
    return {};
  }
  try {
    const response = await axios.post(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        model: "llama3-70b-8192",
        messages: [
          {
            role: "system",
            content:
              "Extract location details from the user input and return ONLY valid JSON with keys: sector, landmark, city, state. Use null for missing fields."
          },
          { role: "user", content: text }
        ],
        temperature: 0.1,
        max_tokens: 200
      },
      {
        headers: {
          Authorization: `Bearer ${GROQ_KEY}`,
          "Content-Type": "application/json"
        }
      }
    );
    const raw = response.data.choices[0].message.content.trim();
    return JSON.parse(raw);
  } catch (err) {
    console.error("AI extract error:", err.message);
    return {};
  }
}

module.exports = { extract };
