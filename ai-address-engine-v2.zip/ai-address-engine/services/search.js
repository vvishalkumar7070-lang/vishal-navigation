const axios = require("axios");

const BASE_URL = "https://nominatim.openstreetmap.org/search";

/**
 * Geocodes a query string using OpenStreetMap Nominatim (India only).
 * @param {string} query
 * @returns {Array} Array of result objects
 */
async function search(query) {
  if (!query || !query.trim()) return [];
  try {
    const response = await axios.get(BASE_URL, {
      params: {
        q: query + ", India",
        format: "json",
        limit: 5,
        countrycodes: "in",
        addressdetails: 1
      },
      headers: {
        "Accept-Language": "en",
        "User-Agent": "VishalNavigation/2.0"
      },
      timeout: 8000
    });
    return response.data || [];
  } catch (err) {
    console.error("Search error:", err.message);
    return [];
  }
}

/**
 * Fetches nearby POIs using the Overpass API within a given radius.
 * @param {number} lat
 * @param {number} lon
 * @param {number} radius - meters (default 200)
 * @returns {Array} Array of { name, type, distance }
 */
async function fetchNearby(lat, lon, radius = 200) {
  const query = `
    [out:json][timeout:10];
    (
      node["amenity"](around:${radius},${lat},${lon});
      node["shop"](around:${radius},${lat},${lon});
      node["tourism"](around:${radius},${lat},${lon});
      node["historic"](around:${radius},${lat},${lon});
      way["amenity"](around:${radius},${lat},${lon});
      way["shop"](around:${radius},${lat},${lon});
    );
    out center 50;
  `;
  try {
    const response = await axios.post(
      "https://overpass-api.de/api/interpreter",
      query,
      { timeout: 10000 }
    );
    return (response.data.elements || [])
      .filter(e => e.tags && (e.tags.name || e.tags["name:en"]))
      .map(e => {
        const name = e.tags["name:en"] || e.tags.name;
        const type = e.tags.amenity || e.tags.shop || e.tags.tourism || e.tags.historic || "place";
        const elat = e.lat || e.center?.lat;
        const elon = e.lon || e.center?.lon;
        let distance = "";
        if (elat && elon) {
          const dx = (lon - elon) * 111320 * Math.cos((lat * Math.PI) / 180);
          const dy = (lat - elat) * 110540;
          distance = `~${Math.round(Math.sqrt(dx * dx + dy * dy))}m`;
        }
        return { name, type: type.replace(/_/g, " "), distance };
      })
      .slice(0, 10);
  } catch (err) {
    console.error("Nearby fetch error:", err.message);
    return [];
  }
}

module.exports = { search, fetchNearby };
