require("dotenv").config();

const express = require("express");
const path = require("path");
const apiRoutes = require("./routes/api");
const pageRoutes = require("./routes/pages");

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

app.use("/api", apiRoutes);
app.use("/", pageRoutes);

app.get("/health", (req, res) => {
  res.json({ status: "ok", version: "2.0.0" });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Vishal Navigation running on http://localhost:${PORT}`));
