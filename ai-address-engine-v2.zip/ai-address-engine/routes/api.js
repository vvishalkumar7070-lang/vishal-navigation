const express = require("express");
const { process }       = require("../engine/processor");
const { addCorrection, getAllCorrections, getCacheSize } = require("../memory/memory");

const router = express.Router();

// POST /api/text — main search endpoint
router.post("/text", async (req, res) => {
  const { text } = req.body;
  if (!text || !text.trim()) {
    return res.status(400).json({ error: "text field is required" });
  }
  try {
    const result = await process(text.trim());
    res.json(result);
  } catch (err) {
    console.error("Process error:", err);
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/correct — save a manual correction
router.post("/correct", (req, res) => {
  const { input, output } = req.body;
  if (!input || !output) {
    return res.status(400).json({ error: "input and output are required" });
  }
  addCorrection(input.trim(), output);
  res.json({ status: "saved" });
});

// GET /api/stats — admin stats
router.get("/stats", (req, res) => {
  res.json({
    cacheSize: getCacheSize(),
    corrections: getAllCorrections()
  });
});

module.exports = router;
