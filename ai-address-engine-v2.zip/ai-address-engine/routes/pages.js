const express = require("express");
const path = require("path");

const router = express.Router();

// Serve the main frontend
router.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

// Agent (debug/dev) view
router.get("/agent", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/agent.html"));
});

// Admin corrections panel
router.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/admin.html"));
});

module.exports = router;
