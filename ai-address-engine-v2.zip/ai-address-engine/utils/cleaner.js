// Common filler words in Indian English / Hinglish queries
const FILLERS = /(haan|hmm|acha|bhai|sir|please|yaar|ji|okay|ok)\b/gi;

// Common misspellings for Indian location terms
const TYPO_MAP = {
  "sekter": "sector",
  "secotr": "sector",
  "sectr":  "sector",
  "gurgaun": "gurgaon",
  "gurugram": "gurugram",
  "banglaore": "bangalore",
  "bangalroe": "bangalore",
  "chenai": "chennai",
  "mumbia": "mumbai",
  "kolkatta": "kolkata",
  "hydrabad": "hyderabad",
  "lucknow": "lucknow",
  "jaipr": "jaipur",
};

/**
 * Strips filler words and lowercases input.
 * @param {string} text
 * @returns {string}
 */
function clean(text) {
  return text
    .toLowerCase()
    .replace(FILLERS, "")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Fixes common spelling mistakes in location names.
 * @param {string} text
 * @returns {string}
 */
function normalize(text) {
  let result = text;
  for (const [wrong, right] of Object.entries(TYPO_MAP)) {
    result = result.replace(new RegExp(`\\b${wrong}\\b`, "gi"), right);
  }
  return result;
}

module.exports = { clean, normalize };
