# 🧭 Vishal Navigation — AI Address Engine

> Find any Indian address with pincode, post office & 10 nearby landmarks in seconds.

![India](https://img.shields.io/badge/Coverage-All%20India-orange)
![Node](https://img.shields.io/badge/Node.js-18%2B-green)
![License](https://img.shields.io/badge/License-MIT-blue)

---

## ✨ Features

- 🔍 **Smart geocoding** — finds any Indian address, colony, sector or landmark
- 📮 **Pincode & post office** detection
- 🏙️ **10 nearby landmarks** within 200m (temples, hospitals, markets, schools…)
- 🤖 **AI extraction** via Groq LLaMA — understands natural language & Hinglish
- ✏️ **Auto spell-correction** for common Indian place typos
- 💾 **In-memory cache** + manual correction system
- 🗺️ **Google Maps deep links** for every result

---

## 🗂️ Project Structure

```
ai-address-engine/
├── app.js                  # Express entry point
├── package.json
├── .env.example            # Copy to .env and add your keys
│
├── /services
│   ├── ai.js               # Groq LLaMA extraction
│   └── search.js           # Nominatim + Overpass geocoding
│
├── /engine
│   ├── processor.js        # Main pipeline (clean → extract → geocode → score)
│   └── scorer.js           # Result ranking
│
├── /memory
│   └── memory.js           # In-memory cache & corrections
│
├── /utils
│   └── cleaner.js          # Text cleaning & typo normalization
│
├── /routes
│   ├── api.js              # REST API routes
│   └── pages.js            # HTML page routes
│
└── /public
    ├── index.html          # Main user-facing UI
    ├── agent.html          # Developer/debug view (raw JSON)
    └── admin.html          # Admin corrections panel
```

---

## 🚀 Quick Start

### 1. Clone & install

```bash
git clone https://github.com/YOUR_USERNAME/ai-address-engine.git
cd ai-address-engine
npm install
```

### 2. Set up environment

```bash
cp .env.example .env
# Edit .env and add your GROQ_API_KEY
```

Get a free Groq API key at [console.groq.com](https://console.groq.com)

### 3. Run

```bash
npm start
# → http://localhost:3000
```

For development with auto-reload:
```bash
npm run dev   # requires: npm install -g nodemon
```

---

## 🔌 API Reference

### `POST /api/text`

Search for a location.

**Request:**
```json
{ "text": "Chandni Chowk Delhi" }
```

**Response:**
```json
{
  "best": {
    "display_name": "Chandni Chowk, New Delhi, Delhi, India",
    "lat": "28.6506",
    "lon": "77.2301",
    "address": { "postcode": "110006", "state": "Delhi" }
  },
  "nearby": [
    { "name": "Jama Masjid", "type": "place of worship", "distance": "~120m" }
  ],
  "suggestions": [...],
  "confidence": 100,
  "source": "live"
}
```

### `POST /api/correct`

Save a manual correction (Admin).

```json
{ "input": "gurgaun sec 14", "output": "Sector 14, Gurugram" }
```

### `GET /api/stats`

Returns cache size and all saved corrections.

---

## 🌐 Pages

| URL | Description |
|-----|-------------|
| `/` | Main user interface |
| `/agent` | Raw JSON debug view |
| `/admin` | Manual corrections panel |

---

## ⚙️ Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `GROQ_API_KEY` | Yes | Groq API key for LLaMA extraction |
| `PORT` | No | Server port (default: 3000) |

---

## 🛠️ Tech Stack

- **Backend:** Node.js + Express
- **AI:** Groq (LLaMA 3 70B)
- **Geocoding:** OpenStreetMap Nominatim
- **Nearby POIs:** Overpass API
- **Frontend:** Vanilla JS + CSS (no framework)

---

## 📄 License

MIT — free to use and modify.
